@extends('layouts.app')
@section('title', 'Flight Page')
@section('content')
<div class="text-center">
  Welcome to the application
</div>
@endsection
