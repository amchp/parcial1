<?php $__env->startSection('title', 'Flight Page'); ?>
<?php $__env->startSection('content'); ?>
<div class="text-center">
  Welcome to the application
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/resources/views/home/index.blade.php ENDPATH**/ ?>