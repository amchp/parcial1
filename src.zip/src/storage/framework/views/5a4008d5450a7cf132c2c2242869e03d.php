<?php $__env->startSection('title', 'Flight Statistics'); ?>
<?php $__env->startSection('subtitle', 'Flight Statistics'); ?>
<?php $__env->startSection('content'); ?>
<div class="text-center">
    <h1>National Flight</h1>
    <p>Count: <?php echo e($viewData['nationalFlights']['count']); ?></p>
    <p>Average Price: <?php echo e($viewData['nationalFlights']['averagePrice']); ?></p>
</div>
<div class="text-center">
    <h1>International Flight</h1>
    <p>Count: <?php echo e($viewData['internationalFlights']['count']); ?></p>
    <p>Average Price: <?php echo e($viewData['internationalFlights']['averagePrice']); ?></p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/resources/views/flight/statistic.blade.php ENDPATH**/ ?>