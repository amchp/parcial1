<?php $__env->startSection('title', 'Flights'); ?>
<?php $__env->startSection('subtitle', 'List of flights'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <?php $__currentLoopData = $viewData["flights"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 col-lg-3 mb-2">
        <div class="card">
            <div class="card-body text-center">
                <?php if($flight->getType() == 'International'): ?>
                    <p><?php echo e($flight->getId()); ?>.  <span style="font-weight: bold;"><?php echo e($flight->getName()); ?></span></p>
                <?php else: ?>
                    <p><?php echo e($flight->getId()); ?>.  <?php echo e($flight->getName()); ?></p>
                <?php endif; ?>
                <p><?php echo e($flight->getType()); ?></p>
                <?php if($flight->getType() == 'National'): ?>
                    <p style="color:blue;"><?php echo e($flight->getPrice()); ?></p>
                <?php else: ?>
                    <p><?php echo e($flight->getPrice()); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /workspace/resources/views/flight/index.blade.php ENDPATH**/ ?>